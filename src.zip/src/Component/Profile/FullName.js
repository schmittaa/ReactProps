function FullName (){
    return(
        <div  className="FullName">
            <h1>Khaoula SCHMIDT</h1>
            <br/>
        </div>
    );
}
export default FullName;